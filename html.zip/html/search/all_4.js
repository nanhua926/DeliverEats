var searchData=
[
  ['fee_5fpriority',['FEE_PRIORITY',['../namespaceAppConfig.html#a3c466ad6d8a038072559fa4efcd77a90',1,'AppConfig']]],
  ['fee_5fstandard',['FEE_STANDARD',['../namespaceAppConfig.html#a7c78c8090237696a853cc8ee430a9a1a',1,'AppConfig']]]
];
