var searchData=
[
  ['appconfig',['AppConfig',['../namespaceAppConfig.html',1,'']]]
];
