var searchData=
[
  ['globalsettings_2eh',['GlobalSettings.h',['../GlobalSettings_8h.html',1,'']]]
];
