var searchData=
[
  ['return_5ftime_5fmins',['return_time_mins',['../structActive__Job.html#a876fa529a77e1273160fdef7466696ca',1,'Active_Job']]],
  ['rider',['rider',['../structActive__Job.html#ac0ac3561c9ba5d7a6c5f481a56049416',1,'Active_Job']]]
];
