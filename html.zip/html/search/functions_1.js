var searchData=
[
  ['calculate_5fduration_5fmins',['calculate_duration_mins',['../classDelivery__Rider.html#a81177cf23a12ceef8fcdd823a51d0d6c',1,'Delivery_Rider']]],
  ['can_5ftake_5forder',['can_take_order',['../classDelivery__Rider.html#a417ffb8a7231fd5d88c766975a687284',1,'Delivery_Rider']]]
];
