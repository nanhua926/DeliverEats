var searchData=
[
  ['canaccept',['canAccept',['../classBaseCourier.html#a9fca3eda9898f1b432a461653cc64313',1,'BaseCourier::canAccept()'],['../classPedalCourier.html#a3c0e9ed2748b04b1dc5d6cdf81094f34',1,'PedalCourier::canAccept()']]]
];
