var searchData=
[
  ['current_5fdaily_5fdist',['current_daily_dist',['../classDelivery__Rider.html#a90be0aa61a764f7586a3686003bcb6a1',1,'Delivery_Rider']]]
];
