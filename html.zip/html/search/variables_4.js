var searchData=
[
  ['speed_5fmph',['speed_mph',['../classDelivery__Rider.html#a910f7b4e871d514530d39b986b7e9641',1,'Delivery_Rider']]]
];
