var searchData=
[
  ['name',['name',['../classDelivery__Rider.html#a8205c84aa6aa121e3bd0815f53b263eb',1,'Delivery_Rider']]]
];
