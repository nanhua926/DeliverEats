var searchData=
[
  ['max_5fdaily_5fdist',['max_daily_dist',['../classDelivery__Rider.html#a2bc5abc73f6581c4ea06dd45000a2d7f',1,'Delivery_Rider']]]
];
