var searchData=
[
  ['void_5ftype',['void_type',['../structCatch_1_1detail_1_1void__type.html',1,'Catch::detail']]]
];
