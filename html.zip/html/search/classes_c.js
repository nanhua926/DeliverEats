var searchData=
[
  ['pluralise',['pluralise',['../structCatch_1_1pluralise.html',1,'Catch']]],
  ['predicatematcher',['PredicateMatcher',['../classCatch_1_1Matchers_1_1Generic_1_1PredicateMatcher.html',1,'Catch::Matchers::Generic']]]
];
