var searchData=
[
  ['perform_5fdelivery',['perform_delivery',['../classDelivery__Rider.html#a84b776da8fe8956ded622a8c812084c1',1,'Delivery_Rider']]]
];
