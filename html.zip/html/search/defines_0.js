var searchData=
[
  ['catch_5fconfig_5fmain',['CATCH_CONFIG_MAIN',['../tests_8cpp.html#a656eb5868e824d59f489f910db438420',1,'tests.cpp']]]
];
