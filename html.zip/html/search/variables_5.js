var searchData=
[
  ['vehicle_5ftype',['vehicle_type',['../classDelivery__Rider.html#a1d1bd58b50fb625a519060c80e074236',1,'Delivery_Rider']]]
];
