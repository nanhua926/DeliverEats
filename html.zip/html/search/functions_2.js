var searchData=
[
  ['generatereport',['generateReport',['../DispatchSystem_8cpp.html#a323f6fc2ffb3810316a766eafe30bd9e',1,'DispatchSystem.cpp']]],
  ['getname',['getName',['../classBaseCourier.html#a8b7671d3240a6284ff872dc2759b9941',1,'BaseCourier']]],
  ['gettripduration',['getTripDuration',['../classBaseCourier.html#afc82ed5645ecb1fd1f4dca1fd6986388',1,'BaseCourier']]],
  ['gettype',['getType',['../classBaseCourier.html#ac180fc0212d98086fd7790702b814af4',1,'BaseCourier']]]
];
