var searchData=
[
  ['delivery_5frider',['Delivery_Rider',['../classDelivery__Rider.html#aac729e810e20aca3825fc65b74fb78db',1,'Delivery_Rider']]]
];
