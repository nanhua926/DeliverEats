var searchData=
[
  ['nameandtags',['NameAndTags',['../structCatch_1_1NameAndTags.html',1,'Catch']]],
  ['noncopyable',['NonCopyable',['../classCatch_1_1NonCopyable.html',1,'Catch']]]
];
