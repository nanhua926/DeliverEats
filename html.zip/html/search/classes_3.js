var searchData=
[
  ['motorizedcourier',['MotorizedCourier',['../classMotorizedCourier.html',1,'']]]
];
