var searchData=
[
  ['reset_5fday',['reset_day',['../classDelivery__Rider.html#a53b2854c7a4f88e8b1ce3ed8719ad708',1,'Delivery_Rider']]]
];
