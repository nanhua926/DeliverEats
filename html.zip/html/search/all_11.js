var searchData=
[
  ['vehicle_5ftype',['vehicle_type',['../classDelivery__Rider.html#a1d1bd58b50fb625a519060c80e074236',1,'Delivery_Rider']]],
  ['void_5ftype',['void_type',['../structCatch_1_1detail_1_1void__type.html',1,'Catch::detail']]]
];
